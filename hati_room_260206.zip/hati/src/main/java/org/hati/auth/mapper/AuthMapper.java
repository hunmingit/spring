package org.hati.auth.mapper;

public interface AuthMapper {

}
